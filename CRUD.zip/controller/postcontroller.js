const express = require('express');
const router = express.Router();
const Blog = require('../models/Postschema');
const asyncHandler = require('express-async-handler');
const { route } = require('../Routes/posts');
//Get post from db
router.get('/',asyncHandler( async(req,res)=>{
    
        const post = await post.find();
        res.json(post);
}));

//save post into db 

router.post('/',asyncHandler( async(req,res)=>{
    const post = await new post({
        Name : req.body.Name,
        summary : req.body.summary,
        img : req.body.img,
    });
    {
        const savedBlog = await post.save();
        res.json(savedpost);
    
    }
}));

//Get specific post from db
router.get('/:postId',asyncHandler( async(req,res)=>{
    
        const blog = await Blog.findById(req.params.postId);
        res.json(this.post);
    }
));

//Update a specific post
router.patch('/:postId',asyncHandler( async(req,res)=>{
    
        const updatedpost = await post.updateOne({ _id : req.params.blogId},{$set : {Content : req.body.Content,
          DateOfUpdation : Date.now()}});
            res.json(updatedpost);
    }));

//Delete a specific post
router.delete('/:postId',asyncHandler( async(req,res)=>{
    
        const deletedpost =  await Post.deleteOne({ _id : req.params.blogId });
        res.json(deletedpost);
    
}));

module.exports = router;