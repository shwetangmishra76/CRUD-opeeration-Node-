const mongoose = require('mongoose');
const { stringify } = require('querystring');

const postSchema = mongoose.Schema({
    Name: {
        type : String,
        required : true
    },
    summary: {
        type : String,
        required : true
    },

    img:{
        type: String,
        required : true
    }
    
});

module.exports = mongoose.model('post',postSchema);