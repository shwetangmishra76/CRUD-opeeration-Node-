const express = require('express');
const app = express();
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
require('dotenv/config');

app.use(bodyParser.json());

//Import routes
const postRoute = require('./Routes/posts');

//middleware
app.use('/post', postRoute);

//Routes
app.get('/',(req,res)=>{
    res.send('Post');
});

//Connect to database
mongoose.connect(process.env.DB_Connection,  { useNewUrlParser: true, useUnifiedTopology: true },()=>{
    console.log('connected to database');
});

//start listening to server
app.listen(3000);